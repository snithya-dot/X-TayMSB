import tensorflow as tf

COEFFS = (5.0 / 2.0, -2.0, 1.0 / 2.0)
EPS = 1e-6
MAX_VALUE = 1e6

def msle_loss(y_true, y_pred):
    safe_pred = tf.clip_by_value(y_pred, 0.0, MAX_VALUE)
    safe_true = tf.clip_by_value(y_true, 0.0, MAX_VALUE)
    return tf.reduce_mean(tf.square(tf.math.log1p(safe_true) - tf.math.log1p(safe_pred)))


def baikal_loss(y_true, y_pred):
    safe_pred = tf.clip_by_value(y_pred, EPS, MAX_VALUE)
    safe_true = tf.clip_by_value(y_true, 0.0, MAX_VALUE)
    return -tf.reduce_mean(tf.math.log(safe_pred) - safe_true / safe_pred)



def hybrid_loss(y_true, y_pred, lambda_weight=0.5):
    l_msle = msle_loss(y_true, y_pred)
    l_bailkal = baikal_loss(y_true, y_pred)
    l_msle_taylor = 2.5 * l_msle - 2.0 * l_msle + 0.5 * l_msle
    l_bailkal_taylor = 2.5 * l_bailkal - 2.0 * l_bailkal + 0.5 * l_bailkal
    l_hyb = l_msle_taylor + lambda_weight * l_bailkal_taylor

    return l_hyb


def loss_function(y_true, y_pred, learning_rate=1e-3, lambda_weight=0.5):
    with tf.GradientTape() as tape:
        l_hyb = hybrid_loss(y_pred=y_pred, y_true=y_true, lambda_weight=lambda_weight)

    grads = tape.gradient(l_hyb)
    loss = [tf.zeros_like(var) if grad is None else learning_rate * grad for grad, var in zip(grads)]
    return loss
