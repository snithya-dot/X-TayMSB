from Proposed_X_TayMSB import Loss_fn
from tensorflow.keras import layers, models, optimizers
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


def separable_block(x, filters, dropout_rate):
    shortcut = layers.Conv1D(filters, 1, strides=2, padding="same")(x)
    x = layers.SeparableConv1D(filters, 3, padding="same")(x)
    x = layers.SeparableConv1D(filters, 3, padding="same")(x)
    x = layers.BatchNormalization()(x)
    if dropout_rate > 0:
        x = layers.Dropout(dropout_rate)(x)
    x = layers.MaxPooling1D(pool_size=2, padding="same")(x)
    return layers.Add()([x, shortcut])


def build_xcovnet(input_shape):
    inputs = layers.Input(shape=input_shape)

    x = layers.Conv1D(4, 3, padding="same")(inputs)
    x = layers.Conv1D(16, 3, padding="same")(x)
    x = layers.MaxPooling1D(pool_size=2, padding="same")(x)

    for filters in (32, 64, 128, 256, 512):
        x = separable_block(x, filters, dropout_rate=0.2)

    x = layers.Flatten()(x)
    x = layers.Dense(64)(x)
    x = layers.PReLU()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(32)(x)
    x = layers.PReLU()(x)
    outputs = layers.Dense(1, activation="sigmoid")(x)

    model = models.Model(inputs, outputs, name="XCovNet")
    return model


def call_main(x_train, y_train, x_test, y_test):
    model = build_xcovnet(input_shape=x_train.shape[1:])

    model.compile(optimizer=optimizers.Adam(learning_rate=0.01), loss=Loss_fn.loss_function, metrics=["accuracy"])

    model.fit(x_train, y_train, epochs=50, batch_size=16, verbose=0)

    y_pred = model.predict(x_test, verbose=0)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1_score_ = f1_score(y_test, y_pred, average='weighted', zero_division=0)

    return accuracy, precision, recall, f1_score_
