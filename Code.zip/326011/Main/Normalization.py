import numpy as np


class MeanNormalization:

    def __init__(self):
        self.mean = None
        self.minimum = None
        self.maximum = None
        self.denominator = None

    def fit(self, data):
        self.mean = np.mean(data, axis=0)
        self.minimum = np.min(data, axis=0)
        self.maximum = np.max(data, axis=0)

        self.denominator = self.maximum - self.minimum
        self.denominator[self.denominator == 0] = 1

        return self

    def transform(self, data):
        return (data - self.mean) / self.denominator

    def fit_transform(self, data):
        self.fit(data)
        return self.transform(data)


def mean_normalization(train_data, test_data):
    normalizer = MeanNormalization()
    x_train_normalized = normalizer.fit_transform(train_data)
    x_test_normalized = normalizer.transform(test_data)

    return x_train_normalized, x_test_normalized
