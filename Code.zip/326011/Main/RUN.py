from Main import Normalization, Feature_selection
from Proposed_X_TayMSB import XConvNet as Proposed_X_TayMSB
from sklearn.model_selection import StratifiedKFold
import pandas as pd
import numpy as np


def call_main(dataset, k_value):
    dn = pd.read_csv("Dataset/" + dataset + ".csv")
    label = dn["Label"]
    dn = dn.drop(columns=["Label"])
    kfold = StratifiedKFold(n_splits=k_value, shuffle=True)
    split_iterator = kfold.split(dn, label)

    accuracy_list = []
    precision_list = []
    recall_list = []
    f1_list = []

    for fold, (train_idx, test_idx) in enumerate(split_iterator, 1):
        # Split training and testing data
        x_train = dn[train_idx]
        x_test = dn[test_idx]

        y_train = np.asarray(label)[train_idx]
        y_test = np.asarray(label)[test_idx]

        normalized_train_data, normalized_test_data = Normalization.mean_normalization(x_train, x_test)

        selected_train_data, selected_test_data = Feature_selection.cdgafs_feature_selection(normalized_train_data, y_train, normalized_test_data, y_test)

        accuracy, precision, recall, f1_score = Proposed_X_TayMSB.call_main(selected_train_data, y_train, selected_test_data, y_test)

        accuracy_list.append(accuracy)
        precision_list.append(precision)
        recall_list.append(recall)
        f1_list.append(f1_score)

    # Calculate aggregated average metrics
    avg_accuracy = np.mean(accuracy_list)
    avg_precision = np.mean(precision_list)
    avg_recall = np.mean(recall_list)
    avg_f1 = np.mean(f1_list)

    return avg_accuracy, avg_precision, avg_recall, avg_f1
