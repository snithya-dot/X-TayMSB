import numpy as np
import networkx as nx
from networkx.algorithms.community import greedy_modularity_communities
from sklearn.neighbors import KNeighborsClassifier


def softmax_scaling(values, mean, spread):
    return 1.0 / (1.0 + np.exp(-(values - mean) / spread))


def fisher_score(x, y):
    overall_mean = x.mean(axis=0)
    numerator = np.zeros(x.shape[1])
    denominator = np.zeros(x.shape[1])
    for c in np.unique(y):
        xc = x[y == c]
        numerator += xc.shape[0] * (xc.mean(axis=0) - overall_mean) ** 2
        denominator += xc.shape[0] * xc.var(axis=0)
    score = numerator / denominator
    return softmax_scaling(score, score.mean(), score.std())


def similarity_matrix(X):
    n = X.shape[1]
    w = np.nan_to_num(np.abs(np.corrcoef(X, rowvar=False)))
    off_diag = w[~np.eye(n, dtype=bool)]
    w_hat = softmax_scaling(w, off_diag.mean(), off_diag.std())
    np.fill_diagonal(w_hat, 0.0)
    return w_hat


def detect_communities(sim, theta):
    n = sim.shape[0]
    graph = nx.Graph()
    graph.add_nodes_from(range(n))
    rows, cols = np.where(np.triu(sim, k=1) >= theta)
    for i, j in zip(rows, cols):
        graph.add_edge(int(i), int(j), weight=float(sim[i, j]))
    return [np.array(sorted(c)) for c in greedy_modularity_communities(graph, weight="weight")]


def initialize_population(communities, n_features, pop_size, omega, rng):
    population = np.zeros((pop_size, n_features), dtype=int)
    for p in range(pop_size):
        for comm in communities:
            picked = rng.choice(comm, size=min(omega, len(comm)), replace=False)
            population[p, picked] = 1
    return population


def fitness(chromosome, x_train, y_train, x_val, y_val, sim, knn_k):
    idx = np.flatnonzero(chromosome)
    m = len(idx)
    if m < 2:
        return 0.0
    knn = KNeighborsClassifier(n_neighbors=knn_k).fit(x_train[:, idx], y_train)
    ca = knn.score(x_val[:, idx], y_val)
    pair_sum = np.triu(sim[np.ix_(idx, idx)], k=1).sum()
    return ca / ((2.0 / (m * (m - 1))) * pair_sum + 1e-12)


def roulette_selection(population, fit, rng):
    total = fit.sum()
    probs = fit / total if total > 0 else np.full(len(population), 1.0 / len(population))
    return population[rng.choice(len(population), size=len(population), p=probs)]


def crossover(parents, rate, rng):
    n = parents.shape[1]
    children = parents.copy()
    for p in range(0, len(parents) - 1, 2):
        if rng.random() < rate:
            a, b = parents[p], parents[p + 1]
            if n < 20:
                c = rng.integers(1, n)
                children[p] = np.concatenate([a[:c], b[c:]])
                children[p + 1] = np.concatenate([b[:c], a[c:]])
            else:
                c1, c2 = np.sort(rng.choice(np.arange(1, n), size=2, replace=False))
                children[p] = np.concatenate([a[:c1], b[c1:c2], a[c2:]])
                children[p + 1] = np.concatenate([b[:c1], a[c1:c2], b[c2:]])
    return children


def mutation(population, rate, rng):
    return np.where(rng.random(population.shape) < rate, 1 - population, population)


def repair(population, communities, fisher, omega, rng):
    for p in range(len(population)):
        for comm in communities:
            target = min(omega, len(comm))
            chosen = comm[population[p, comm] == 1]
            if len(chosen) > target:
                w = 1.0 / (fisher[chosen] + 1e-12)
                w = w / w.sum()
                population[p, rng.choice(chosen, size=len(chosen) - target,
                                         replace=False, p=w)] = 0
            elif len(chosen) < target:
                free = comm[population[p, comm] == 0]
                w = fisher[free] + 1e-12
                w = w / w.sum()
                population[p, rng.choice(free, size=target - len(chosen),
                                         replace=False, p=w)] = 1
    return population


def evaluate_population(population, x_train, y_train, x_val, y_val, sim, knn_k, cache):
    fit = np.zeros(len(population))
    for p in range(len(population)):
        key = population[p].tobytes()
        if key not in cache:
            cache[key] = fitness(population[p], x_train, y_train, x_val, y_val, sim, knn_k)
        fit[p] = cache[key]
    return fit


def cdgafs(x_train, y_train, x_test, y_test, pop_size=80, max_iter=100,
           crossover_rate=0.8, mutation_rate=0.05, omega=3, theta=0.2,
           knn_k=5):

    n_features = x_train.shape[1]

    fisher = fisher_score(x_train, y_train)
    sim = similarity_matrix(x_train)
    communities = detect_communities(sim, theta)
    rng = np.random
    population = initialize_population(communities, n_features, pop_size, omega, rng)
    cache = {}

    for it in range(max_iter):
        fit = evaluate_population(population, x_train, y_train, x_test, y_test, sim, knn_k, cache)
        parents = roulette_selection(population, fit, rng)
        children = crossover(parents, crossover_rate, rng)
        children = mutation(children, mutation_rate, rng)
        population = repair(children, communities, fisher, omega, rng)

    fit = evaluate_population(population, x_train, y_train, x_test, y_test, sim, knn_k, cache)
    best_solution = population[np.argmax(fit)]
    selected_indexes = np.where(best_solution == 1)[0]

    return selected_indexes


def cdgafs_feature_selection(train_data, train_label, test_data, test_label):
    selected_index = cdgafs(train_data, train_label, test_data, test_label)

    train_data = train_data[:, selected_index]
    test_data = test_data[:, selected_index]

    return train_data, test_data
